g++ -o advanced_active_texture Main.cpp VBO.cpp EBO.cpp Texture.cpp shaderClass.cpp -lglfw -lGLESv2
