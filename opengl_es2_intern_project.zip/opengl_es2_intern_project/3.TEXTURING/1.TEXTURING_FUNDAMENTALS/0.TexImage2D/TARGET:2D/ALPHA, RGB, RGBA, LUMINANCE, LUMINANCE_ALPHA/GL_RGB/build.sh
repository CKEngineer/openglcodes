g++ -o deneme main.cpp -lglfw -lGLESv2 -ldl
