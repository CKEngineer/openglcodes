#include <GLFW/glfw3.h>
#include <GLES2/gl2.h>

#define SCR_WIDTH 512
#define SCR_HEIGHT 512

/* Pencere küçültülüp büyütüldüğünde içindeki yapıda buna adapte olacaktır (Basic seviye) */
void framebufferSizeCallback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
    // Diğer gerekli adaptasyon işlemleri burada yapılabilir.
}

int main() {
    /* Pencerenin oluşturulması */

    if (!glfwInit()) {
        return -1;
    }

    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_ES_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Alpha Values Testing", NULL, NULL);
    if (!window) {
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    /* Dikdörtgenin köşeleri pencerinin üst ve alt köşelerinde birer tane var */
    GLfloat vertices[] = {
        -1.0f, -1.0f,   // Sol alt köşe
         1.0f, -1.0f,   // Sağ alt köşe
         1.0f,  1.0f,   // Sağ üst köşe
        -1.0f,  1.0f    // Sol üst köşe
    };

    GLuint indices[] = {
        0, 1, 2,   // İlk üçgen
        0, 2, 3    // İkinci üçgen
    };

    GLfloat texCoord[] = {
        0.0f, 1.0f,
        1.0f, 1.0f,
        1.0f, 0.0f,
        0.0f, 0.0f
    };

    GLuint vertexBuffer;
    glGenBuffers(1, &vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    GLuint elementBuffer;
    glGenBuffers(1, &elementBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    GLuint texCoordBuffer;
    glGenBuffers(1, &texCoordBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, texCoordBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(texCoord), texCoord, GL_STATIC_DRAW);

    const char* vertexShaderCode =
        "attribute vec2 aPosition;\n"
        "attribute vec2 aTexCoord;\n"
        "varying vec2 vTexCoord;\n"
        "void main() {\n"
        "    gl_Position = vec4(aPosition, 0.0, 1.0);\n"
        "    vTexCoord = aTexCoord;\n"
        "}";

    const char* fragmentShaderCode =
        "precision mediump float;\n"
        "varying vec2 vTexCoord;\n"
        "uniform sampler2D uTexture;\n"
        "uniform sampler2D uTexture2;\n"
        "void main() {\n"
        "  vec4 texColor1 = texture2D(uTexture, vTexCoord);\n"
        "  vec4 texColor2 = texture2D(uTexture2, vTexCoord);\n"
        "  gl_FragColor = mix(texColor1, texColor2, texColor2.a*0.5);\n"
        "}";

    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderCode, NULL);
    glCompileShader(vertexShader);

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderCode, NULL);
    glCompileShader(fragmentShader);

    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    glUseProgram(shaderProgram);

    GLint aPosition = glGetAttribLocation(shaderProgram, "aPosition");
    glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
    glVertexAttribPointer(aPosition, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(aPosition);

    GLint aTexCoord = glGetAttribLocation(shaderProgram, "aTexCoord");
    glBindBuffer(GL_ARRAY_BUFFER, texCoordBuffer);
    glVertexAttribPointer(aTexCoord, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(aTexCoord);

    GLuint texture;
    glGenTextures(1, &texture);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);
    GLint uTexture = glGetUniformLocation(shaderProgram, "uTexture");
    glUniform1i(uTexture, 0);

    GLuint texture2;
    glGenTextures(1, &texture2);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, texture2);
    GLint uTexture2 = glGetUniformLocation(shaderProgram, "uTexture2");
    glUniform1i(uTexture2, 1);

unsigned char pixels_of_texture[] = {
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0,
0,255,0

    };

unsigned char glass_pixels_of_texture[] = {
61,
241,
229,
57,
26,
227,
67,
214,
136,
175,
7,
128,
61,
109,
193,
31,
173,
55,
207,
179,
122,
104,
193,
159,
141,
33,
239,
170,
111,
185,
80,
10,
55,
69,
204,
156,
72,
151,
49,
253,
138,
208,
12,
231,
26,
21,
207,
222,
171,
19,
104,
61,
252,
46,
207,
145,
81,
97,
58,
53,
39,
84,
244,
64,
213,
224,
91,
223,
214,
70,
19,
201,
223,
46,
141,
243,
172,
84,
127,
147,
90,
208,
64,
18,
49,
71,
95,
176,
28,
218,
241,
218,
216,
57,
3,
128,
178,
151,
56,
234,
124,
142,
116,
148,
141,
112,
69,
47,
184,
162,
231,
195,
109,
5,
12,
137,
37,
125,
205,
210,
93,
47,
134,
233,
252,
170,
180,
238,
138,
76,
115,
2,
208,
72,
113,
43,
64,
71,
186,
141,
68,
79,
170,
150,
41,
179,
46,
87,
120,
234,
46,
28,
113,
233,
85,
111,
87,
221,
196,
113,
189,
148,
56,
250,
34,
86,
19,
99,
177,
46,
66,
14,
96,
9,
243,
190,
20,
74,
169,
91,
222,
155,
49,
48,
41,
213,
248,
61,
192,
239,
160,
102,
221,
241,
122,
245,
234,
249,
38,
178,
54,
90,
250,
93,
83,
152,
248,
210,
199,
77,
222,
240,
96,
180,
21,
6,
197,
203,
30,
178,
41,
190,
2,
153,
163,
251,
141,
252,
66,
14,
121,
254,
104,
173,
72,
161,
147,
161,
235,
18,
26,
132,
154,
195,
221,
148,
194,
132,
91,
138,
72,
40,
206,
247,
173,
39
    };

    glActiveTexture(GL_TEXTURE0);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 16,16, 0, GL_RGB, GL_UNSIGNED_BYTE, pixels_of_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    
    glActiveTexture(GL_TEXTURE1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, 16, 16, 0, GL_ALPHA, GL_UNSIGNED_BYTE, glass_pixels_of_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glGenerateMipmap(GL_TEXTURE_2D);

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Ekran beyaza boyanır
    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT);
        glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteTextures(1, &texture);
    glDeleteTextures(1, &texture2);
    glDeleteProgram(shaderProgram);
    glDeleteShader(fragmentShader);
    glDeleteShader(vertexShader);
    glDeleteBuffers(1, &vertexBuffer);
    glDeleteBuffers(1, &texCoordBuffer);
    glDeleteBuffers(1, &elementBuffer);

    glfwTerminate();
    return 0;
}
