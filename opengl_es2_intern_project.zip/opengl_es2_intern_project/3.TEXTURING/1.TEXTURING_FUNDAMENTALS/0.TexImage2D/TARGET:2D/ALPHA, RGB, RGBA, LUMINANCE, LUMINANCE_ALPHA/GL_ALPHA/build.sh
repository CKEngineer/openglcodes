g++ -o alpha main.cpp -lglfw -lGLESv2 
