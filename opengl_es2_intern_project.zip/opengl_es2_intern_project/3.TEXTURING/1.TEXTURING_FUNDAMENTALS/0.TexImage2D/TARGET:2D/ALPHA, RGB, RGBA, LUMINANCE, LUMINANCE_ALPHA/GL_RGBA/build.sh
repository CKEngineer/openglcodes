g++ -o temp rgba.cpp -lglfw -lGLESv2 -ldl
./temp