g++ -o pusula main.cpp -lglfw -lGLESv2 
