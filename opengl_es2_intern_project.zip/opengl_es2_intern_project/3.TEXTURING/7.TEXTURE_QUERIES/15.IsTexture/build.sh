g++ -o temp main.cpp -lglfw -lGLESv2 -ldl
./temp