#include <GLES2/gl2.h>
#include <EGL/egl.h>
#include <stdio.h>

const char* vertexShaderCode =
    "attribute vec4 aPosition;\n"
    "void main() {\n"
    "    gl_Position = aPosition;\n"
    "}";

const char* fragmentShaderCode =
    "precision mediump float;\n"
    "void main() {\n"
    "    gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);\n"
    "}";

GLuint loadShader(GLenum type, const char* binaryPath) {
    GLuint shader = glCreateShader(type);
    glShaderBinary(1, &shader, GL_SHADER_BINARY_FORMAT_SPIR_V, binaryPath, sizeof(GLint));
    GLint compileStatus;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compileStatus);
    if (compileStatus != GL_TRUE) {
        char log[512];
        glGetShaderInfoLog(shader, sizeof(log), nullptr, log);
        printf("Shader compile error: %s\n", log);
        glDeleteShader(shader);
        return 0;
    }
    return shader;
}

int main() {
    if (!eglBindAPI(EGL_OPENGL_ES_API)) {
        return -1;
    }

    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLint major, minor;
    eglInitialize(display, &major, &minor);

    EGLConfig config;
    EGLint numConfigs;
    eglChooseConfig(display, nullptr, &config, 1, &numConfigs);

    EGLSurface surface = eglCreateWindowSurface(display, config, EGL_DEFAULT_DISPLAY, nullptr);
    EGLContext context = eglCreateContext(display, config, EGL_NO_CONTEXT, nullptr);
    eglMakeCurrent(display, surface, surface, context);

    GLuint program = glCreateProgram();
    GLuint vertexShader = loadShader(GL_VERTEX_SHADER, "vertex_shader.spv");
    GLuint fragmentShader = loadShader(GL_FRAGMENT_SHADER, "fragment_shader.spv");
    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);
    glLinkProgram(program);
    glUseProgram(program);

    GLfloat vertices[] = {
        0.0f,  0.5f, 0.0f,
       -0.5f, -0.5f, 0.0f,
        0.5f, -0.5f, 0.0f
    };

    GLuint vbo;
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    GLint aPosition = glGetAttribLocation(program, "aPosition");
    glVertexAttribPointer(aPosition, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), nullptr);
    glEnableVertexAttribArray(aPosition);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    eglSwapBuffers(display, surface);

    eglDestroySurface(display, surface);
    eglDestroyContext(display, context);
    eglTerminate(display);

    return 0;
}
