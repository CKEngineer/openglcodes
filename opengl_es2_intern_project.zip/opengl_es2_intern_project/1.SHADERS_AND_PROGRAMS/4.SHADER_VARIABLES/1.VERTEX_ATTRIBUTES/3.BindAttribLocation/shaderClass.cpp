#include"shaderClass.h"

// Reads a text file and outputs a string with everything in the text file
std::string get_file_contents(const char* filename)
{
	std::ifstream in(filename, std::ios::binary);
	if (in)
	{
		std::string contents;
		in.seekg(0, std::ios::end);
		contents.resize(in.tellg());
		in.seekg(0, std::ios::beg);
		in.read(&contents[0], contents.size());
		in.close();
		return(contents);
	}
	throw(errno);
}

// Constructor that build the Shader Program from 2 different shaders
Shader::Shader(const char* vertexFile, const char* fragmentFile)
{
	// Read vertexFile and fragmentFile and store the strings
	std::string vertexCode = get_file_contents(vertexFile);
	std::string fragmentCode = get_file_contents(fragmentFile);

	// Convert the shader source strings into character arrays
	const char* vertexSource = vertexCode.c_str();
	const char* fragmentSource = fragmentCode.c_str();

	// Create Vertex Shader Object and get its reference
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
	// Attach Vertex Shader source to the Vertex Shader Object
	glShaderSource(vertexShader, 1, &vertexSource, NULL);
	// Compile the Vertex Shader into machine code
	glCompileShader(vertexShader);
	// Checks if Shader compiled succesfully
	compileErrors(vertexShader);

	// Create Fragment Shader Object and get its reference
	GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	// Attach Fragment Shader source to the Fragment Shader Object
	glShaderSource(fragmentShader, 1, &fragmentSource, NULL);
	// Compile the Vertex Shader into machine code
	glCompileShader(fragmentShader);
	// Checks if Shader compiled succesfully
	compileErrors(fragmentShader);

	// Create Shader Program Object and get its reference
	ID = glCreateProgram();
	// Attach the Vertex and Fragment Shaders to the Shader Program
	glAttachShader(ID, vertexShader);
	glAttachShader(ID, fragmentShader);
	//Bind Attribute Location here:
    glBindAttribLocation(ID,0,"aPosition");
	glBindAttribLocation(ID,1,"aColor");
    // Wrap-up/Link all the shaders together into the Shader Program
	glLinkProgram(ID);
	// Checks if Shaders linked succesfully
	glValidateProgram(ID);

	compileErrors(ID);
	
    glReleaseShaderCompiler();
	// Delete the now useless Vertex and Fragment Shader objects
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);



}

// Activates the Shader Program
void Shader::Activate()
{
	glUseProgram(ID);
}

// Deletes the Shader Program
void Shader::Delete()
{
	glDeleteProgram(ID);
}



// Checks if the different Shaders have compiled properly
void Shader::compileErrors(unsigned int graphic_object)
{
	// Stores status of compilation
	GLint hasCompiled;
	GLint hasLinked;
	GLint isValidate;
	//In case of shader type comes
	GLint shaderType;
	// Character array to store error message in
	

	if (glIsShader(graphic_object))
	{
		glGetShaderiv(graphic_object,GL_SHADER_TYPE,&shaderType);
		glGetShaderiv(graphic_object,GL_COMPILE_STATUS,&hasCompiled);
		if (hasCompiled == GL_FALSE)
		{
			char infoLog[1024];
			switch (shaderType)
			{
			case GL_VERTEX_SHADER:
				glGetShaderInfoLog(graphic_object, 1024, NULL, infoLog);
				std::cout << "SHADER_COMPILATION_ERROR for:" << "VERTEX" << "\n" << infoLog << std::endl;
				break;
			case GL_FRAGMENT_SHADER:
				glGetShaderInfoLog(graphic_object, 1024, NULL, infoLog);
				std::cout << "SHADER_COMPILATION_ERROR for:" << "FRAGMENT" << "\n" << infoLog << std::endl;
				break;
			default:
				std::cout << "UNKNOWN ERROR IN SHADER\n" << infoLog << std::endl;
				break;
			}

		}
	}
	else if(glIsProgram(graphic_object))
	{
		char infoLog[1024];
		glGetProgramiv(graphic_object, GL_LINK_STATUS, &hasLinked);
		if (hasLinked == GL_FALSE)
		{
			glGetProgramInfoLog(graphic_object, 1024, NULL, infoLog);
			std::cout << "SHADER_LINKING_ERROR for:" << "PROGRAM" << "\n" << infoLog << std::endl;
		}

		glGetProgramiv(graphic_object,GL_VALIDATE_STATUS,&isValidate);
		if(isValidate == GL_TRUE){
            std::cout << "VALIDATION is succesfull" << "\n" << infoLog << std::endl;
		}
		else{
			std::cout << "VALIDATION is failed" << "\n" << infoLog << std::endl;
		}
		
	}

}
