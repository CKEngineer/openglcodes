g++ -o my_animated_colorful_triangle main.cpp -lglfw -lGL 
