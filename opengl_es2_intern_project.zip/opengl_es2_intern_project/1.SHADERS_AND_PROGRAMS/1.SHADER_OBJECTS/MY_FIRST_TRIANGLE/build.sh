g++ -o my_first_triangle main.cpp -lglfw -lGL 
