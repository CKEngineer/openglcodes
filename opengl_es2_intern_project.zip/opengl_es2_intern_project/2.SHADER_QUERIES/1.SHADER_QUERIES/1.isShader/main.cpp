#include <GLFW/glfw3.h>
#include <GLES2/gl2.h>
#include <stdio.h>


/*
void glGetShaderiv(GLuint shader, GLenum pname, GLint *params):
Shader ile ilgili bilgilerin sorgulanmasını yapar.

Parametreler:

GLuint shader:
Hangi shader nesnesinin sorgulanacağını belirtir

GLenum pname
Hedef olan parametreyi belirtir. Kabul edilen sembolik değerler 
GL_SHADER_TYPE, 
GL_DELETE_STATUS, 
GL_COMPILE_STATUS, 
GL_INFO_LOG_LENGTH, 
GL_SHADER_SOURCE_LENGTH.


GLint *params
hedef hedef parametre hakkında durumun ne olduğuna dair fonskiyon dönüş yapar.

hedef parametre GL_SHADER_TYPE ise
params eğer vertex shader ise GL_VERTEX_SHADER değerine döner fragment shader ise GL_FRAGMENT_SHADER değerine döner.

hedef parametre GL_DELETE_STATUS ise
params shader silme işlemi için bayrak çekilmişse(ayarlanmışsa) GL_TRUE değerini döner , değilse GL_FALSE değerini döner.

hedef parametre GL_COMPILE_STATUS ise
Shader derleyiciyi destekleyen implamantasyonlar içindir, eğer shader içindeki kaynak dosyanın derlemesi başarılıysa GL_TRUE değilses GL_FALSE değerinin dönderir

hedef parametre GL_INFO_LOG_LENGTH ise
Shader derleyiciyi destekleyen implamantasyonlar içindir, parametre shader için bilgilendirme logu içindeki karakter sayısı değerine döner
null sonlandırma karakteride buna dahildir. (kullanımına örnek olarak karakterler için gerekli olan buffer büyüklüğüne döner çünkğ bilgilendirme logunu depolamak için gereklidir.). 
Eğer shaderın bilgilendirme logu gerçekleşmediyse 0 değerini dönderir.

hedef parametre GL_SHADER_SOURCE_LENGTH ise
Shader derleyiciyi destekleyen implamantasyonlar içindir, params returns the length of the concatenation of 
the source strings that make up the shader source for the shader, sonlandırma karakteri dahildir.
(i.e., the size of the character buffer required to store the shader source). If no source code exists, 0 is returned.


*/


int main() {
    if (!glfwInit()) {
        return -1;
    }
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_ES_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);

    GLFWwindow* window = glfwCreateWindow(800, 600, "OpenGL ES 2.0 Üçgen Örneği", NULL, NULL);
    if (!window) {
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window); 
    /*
    const GLubyte* renderer = glGetString(GL_RENDERER);
    const GLubyte* version = glGetString(GL_VERSION);
    printf("Renderer: %s\n", renderer);
    printf("OpenGL version supported: %s\n", version);
    */
    GLfloat vertices[] = {
        0.0f,  0.6f,
       -0.6f, -0.6f,
        0.6f, -0.6f
    };

    GLuint vertexBuffer;
    glGenBuffers(1, &vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    const char* vertexShaderCode =
        "attribute vec2 aPosition;\n"
        "void main() {\n"
        "    gl_Position = vec4(aPosition, 0.0, 1.0);\n"
        "}";

    const char* fragmentShaderCode =
        "precision mediump float;\n"
        "void main() {\n"
        "    gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);\n"
        "}";


    /*
    glCreateShader bir tane boş bir shader nesnesi oluşturur ve parametre olarak hangi shader olacağına dair bir sabit alur:
    GL_VERTEX_SHADER ve GL_FRAGMENT_SHADER değerlerinin ikisinden birini almak zorunda bu shader nesnesi içine ilgili shader ile ilgili
    source kodu içine alır fonksiyon başarısız olursa 0 değerini dönderir içine geçersiz parametre gönderilirse GL_INVALID_ENUM değeri dönderilir.
    */
    
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderCode, NULL);
    glCompileShader(vertexShader);

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderCode, NULL);
    glCompileShader(fragmentShader);

    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    glUseProgram(shaderProgram);

    GLint aPosition = glGetAttribLocation(shaderProgram, "aPosition");
    glVertexAttribPointer(aPosition, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(aPosition);

    

    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT);

        glDrawArrays(GL_TRIANGLES, 0, 3);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    
    /*ilgili shaderların döndürdüğü değerler konsola yazdırılmıştır:*/
    printf("\nVertex Shader:%u",vertexShader);
    printf("\nFragment Shader:%u\n",fragmentShader);

    glDeleteProgram(shaderProgram);
    glDeleteShader(fragmentShader);
    glDeleteShader(vertexShader);
    glDeleteBuffers(1, &vertexBuffer);

    glfwTerminate();
    return 0;
}
