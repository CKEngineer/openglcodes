g++ -o temp main.cpp -lglfw -lGL
./temp