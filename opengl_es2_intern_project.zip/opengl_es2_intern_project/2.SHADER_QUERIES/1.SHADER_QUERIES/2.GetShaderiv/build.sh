g++ -o temp main.cpp -lglut -lGLU -lGL
./temp