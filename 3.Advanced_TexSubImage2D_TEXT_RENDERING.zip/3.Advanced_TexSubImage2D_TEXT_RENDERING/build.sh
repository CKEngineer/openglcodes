g++ -o advanced_glTexSubImage2D Main.cpp VBO.cpp EBO.cpp Texture.cpp shaderClass.cpp -lglfw -lGLESv2
